package kumoh.d445.ucopyicatch.daumdataminig;

public class RequestUrls {
	//블로그 API 주소
	public static final String BLOG_REQUEST_URL = "https://apis.daum.net/search/blog";

}
