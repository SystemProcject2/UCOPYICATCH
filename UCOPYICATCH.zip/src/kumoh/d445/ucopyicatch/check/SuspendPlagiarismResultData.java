package kumoh.d445.ucopyicatch.check;

import java.util.ArrayList;

public class SuspendPlagiarismResultData {
	private ArrayList<SuspendPlagiarismResultItemData> result = new ArrayList<SuspendPlagiarismResultItemData>();;
	
	public ArrayList<SuspendPlagiarismResultItemData> getResult() {
		return result;
	}
}
