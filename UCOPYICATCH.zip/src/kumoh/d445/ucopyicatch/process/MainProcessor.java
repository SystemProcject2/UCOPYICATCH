package kumoh.d445.ucopyicatch.process;

public class MainProcessor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1. 대상 독후감 받기
		//2. 대상 독후감 분석
		//3. 디비 읽기(대상 독후감과 디비 합치기)
		//4. 메트릭스 구성
		//5. 표절 검사(lsa부터 테스트)
	}

}
