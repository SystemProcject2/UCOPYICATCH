package kumoh.d445.ucopyicatch.process;

public class PreProcessor {
	public static void main(String[] args)
	{
		//1. 내용을 가져온다
		
		//2. 문장분석
		//3. 디비 저장
	}
}
